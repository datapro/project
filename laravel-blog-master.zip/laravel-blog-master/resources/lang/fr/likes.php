<?php

return [
    'likes' => "J'aime",
];
