<?php

return [
  'none' => 'Aucun',
  'admin' => "Administrateur",
  'editor' => "Éditeur",
];
