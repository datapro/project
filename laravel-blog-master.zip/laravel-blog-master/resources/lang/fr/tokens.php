<?php

return [
  'updated' => "La clé d'API a bien été générée"
];
