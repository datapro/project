<?php

return [
    'dashboard' => 'Dashboard',
    'this_week' => 'Cette semaine',
    'details' => 'Voir en détails',
    'posts' => 'Articles',
    'comments' => 'Commentaires',
    'users' => 'Utilisateurs',
    'media' => 'Galerie',
];
