<?php

return [
    'dashboard' => 'Dashboard',
    'this_week' => 'This week',
    'details' => 'Details',
    'posts' => 'Posts',
    'comments' => 'Comments',
    'users' => 'Users',
    'media' => 'Gallery',
];
