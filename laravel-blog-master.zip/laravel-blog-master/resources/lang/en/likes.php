<?php

return [
    'likes' => "Likes",
];
