<?php

return [
  'none' => 'None',
  'admin' => "Administrator",
  'editor' => "Editor",
];
